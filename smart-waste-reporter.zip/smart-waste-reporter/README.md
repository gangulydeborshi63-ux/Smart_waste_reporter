# Smart Waste Reporter

Smart Waste Reporter is a hackathon-ready civic-tech prototype for reporting, verifying, assigning, cleaning, and resolving waste incidents. It includes a fully interactive local demo mode so judges can experience the workflow without real government data or Firebase credentials.

## Run locally

Open `index.html` through a static server such as VS Code Live Server so ES modules load correctly. The current environment does not include Node.js, so this prototype uses browser import maps. For a production React build, install Node.js 20+, add the standard Vite React package files, run `npm install`, then `npm run dev`.

## Demo flow

Use the role switcher in the top bar to act as Citizen, Authority, or Worker. Citizen reports are stored in localStorage. Authority can verify, assign, and prioritize them. Worker can start a task and submit after-cleanup evidence. Authority can then resolve or reopen the report. Seeded content is clearly labelled demo data.

## Firebase configuration

Copy `.env.example` to `.env` and add Firebase Web App values. The intended production adapters are Firebase Authentication for login and role claims, Firestore for reports/status history, and Cloud Storage for validated images. Security rules must enforce role ownership and file limits server-side.

## Architecture

`src/pages` is represented by role-focused view components in the MVP, `src/components` is represented by reusable components, `src/services` contains storage and AI seams, and `src/hooks` contains workflow state. The demo repository uses a local adapter with the same report shape planned for Firestore.

## AI integration

`src/services/aiService.js` exposes `analyzeWasteImage`. The default development adapter is explicitly mock-only and returns a deterministic suggestion. Replace it with a secured API call to a custom YOLOv8 service. Target classes are Plastic, Glass, Organic, Paper, and Metal. Suggestions at or above 0.75 confidence can be surfaced automatically; lower confidence requires manual confirmation. One image may produce multiple detections.

## Future hardening

Add Firebase App Check, custom claims, Firestore and Storage rules, Cloud Functions for duplicate checks and notifications, a real Leaflet tile layer, service-worker sync where supported, and a trained YOLOv8 model. GPS is treated as a validation signal, not proof.
