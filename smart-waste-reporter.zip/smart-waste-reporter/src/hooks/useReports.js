import { useState } from 'react';
import { createReport, loadReports, saveReports } from '/src/services/demoStore.js';
export function useReports() {
  const [reports, setReports] = useState(loadReports);
  const update = (next) => { setReports(next); saveReports(next); };
  const add = (data) => { const report = createReport(data); update([report, ...reports]); return report; };
  const transition = (id, status, label, extra = {}) => update(reports.map((report) => report.id === id ? { ...report, ...extra, status, history: [...report.history, { status, label, at: 'Just now' }] } : report));
  return { reports, add, transition };
}
