const TARGET_CLASSES = ['Plastic', 'Glass', 'Organic', 'Paper', 'Metal'];
export const AI_CONFIDENCE_THRESHOLD = 0.75;

// Development adapter: intentionally mock until a secured YOLOv8 endpoint exists.
export async function analyzeWasteImage(file) {
  const name = file?.name?.toLowerCase() || '';
  const category = name.includes('glass') ? 'Glass' : name.includes('paper') ? 'Paper' : 'Plastic';
  return { adapter: 'mock-development', detections: [{ label: category, confidence: 0.86 }], targetClasses: TARGET_CLASSES };
}
